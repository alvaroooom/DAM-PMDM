import { Component, input, output } from '@angular/core';
import { Vehicle } from '../../interface/vehicle-list-response';

@Component({
  imports: [],
  selector: 'app-vehicle-item',
  styleUrl: './vehicle-item.css',
  templateUrl: './vehicle-item.html',
})
export class VehicleItemComponent {
  vehicle = input<Vehicle>();

  vehicleClicked = output<string>();
  id: string = ' ';

  getVehicleId() {
    this.id = this.vehicle()?.url[6] ?? '';
    return this.id;
  }

  emitVehicleClicked() {
    const id = this.getVehicleId();
    this.vehicleClicked.emit(id);
  }
}
