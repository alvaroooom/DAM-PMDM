import { Component, inject, OnInit, signal } from '@angular/core';
import { VehicleService } from '../../services/vehicle-service';
import { Vehicle } from '../../interface/vehicle-list-response';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { VehicleModal } from '../vehicle-modal/vehicle-modal';
import { VehicleItemComponent } from '../vehicle-item/vehicle-item';

@Component({
  imports: [VehicleItemComponent],
  selector: 'app-vehicle-list',
  styleUrl: './vehicle-list.css',
  templateUrl: './vehicle-list.html',
})
export class VehicleListComponent implements OnInit {

  vehicleService = inject(VehicleService);
  vehicleList = signal<Vehicle[]>([]);
  private modalService = inject(NgbModal);

  ngOnInit(): void {
    this.vehicleService.getAll().subscribe(resp => {
      this.vehicleList.set(resp.results);
    });
  }
  openVehicleModal(id: string) {
    this.vehicleService.getOne(id).subscribe(resp => {

      const modalRef = this.modalService.open(VehicleModal);
      modalRef.componentInstance.vehicleDetail = resp;
    });

  }
}
