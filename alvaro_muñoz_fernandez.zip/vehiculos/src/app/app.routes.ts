import { Routes } from '@angular/router';
import { VehicleListComponent } from './components/vehicle-list/vehicle-list';
import { Home } from './pages/home/home';

export const routes: Routes = [
    {path: '', pathMatch: 'full', component: Home},
    {path: 'vehicle-list', component: VehicleListComponent},
    {path: '**', redirectTo: ''}
];
